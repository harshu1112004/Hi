<p align="center">
<a href="#"><img title="Made in India" src="https://img.shields.io/badge/MADE%20IN-INDIA-green?colorA=%23f5690c&colorB=%23035c00&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="InstaReporter" src="https://1.bp.blogspot.com/-MBk0TXc1dYg/X89zgPXgCMI/AAAAAAAAAr4/WZMSQHlTu-szSNwhM2OulWp95RG4F1gjQCLcBGAsYHQ/s1899/InstaReporter.jpg"></a>
</p>
<p align="center">
<a href="https://github.com/muneebwanee"><img title="Author" src="https://img.shields.io/badge/Author-muneeb--wanee-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="#"><img title="Language" src="https://1.bp.blogspot.com/-5tHttPts7BU/X89wVngejyI/AAAAAAAAArU/lTYDMdxiFuou_AIVuhaByD0fDNnmd07PQCLcBGAsYHQ/s2340/Language.jpg"></a></p>

## Installation :

* `apt update`
* `apt install git curl php wget -y`
* `git clone https://github.com/muneebwanee/InstaReporter.git`
* `cd InstaReporter`
#### > Run : `python3 InstaReporter.py`

## Single Command :
```
apt update ; apt install git curl wget php -y ; git clone https://github.com/muneebwanee/InstaReporter.git ; cd InstaReporter ; python3 InstaReporter.py
```
<br>
<p align="center">
<img width="80%" src="https://1.bp.blogspot.com/-xg_-lSS2yRs/X89wwmb5mOI/AAAAAAAAArc/ZL3SFJ-NSagBJvp7qspKx2e5QhmndeKygCLcBGAsYHQ/s2048/method.png"/>

</p>

### <<< If you copy , Then Give me The Credits >>>

## Features :
#### [+] Latest Report Method !
#### [+] Based On Proxies !
#### [+] Easy for Beginners !
 
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://github.com/muneebwanee"><img title="Followers" src="https://img.shields.io/github/followers/muneebwanee?color=blue&style=flat-square"></a>
<a href="https://twitter.com/muneebwanee"><img title="Twitter" src="https://img.shields.io/twitter/follow/muneebwanee?style=social"></a>
<a href="https://twitter.com/the_deepnet"><img title="Contributer" src="https://img.shields.io/twitter/follow/the_deepnet?label=%40the_deepnet&style=social"></a>
<a href="https://instagram.com/muneebwanee"><img title="Instagram" src="https://img.shields.io/badge/IG-%40muneebwanee-red?style=for-the-badge&logo=instagram"></a>
<a href="https://linkedin.com/in/muneebwanee"><img title="LinkedIn" src="https://img.shields.io/badge/LinkedIn%20-muneebwanee-orange?colorA=%23ff9696&colorB=%237E7B4E&style=for-the-badge"></a>
<a href="https://m.me/me.muneebwanee"><img title="Facebook" src="https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger"></a>
<a href="https://github.com/muneebwanee"><img title="GitHub" src="https://img.shields.io/badge/Github-Muneeb--Wanee-green?style=for-the-badge&logo=github"></a>
<a href="https://www.buymeacoffee.com/muneebwanee" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>
</p>
